# bootstrap-webpack-V09
# test change

Bootstrap scss as single file and purged
	
Independent option for minify css if required
	
Option to add bootstrap modules as required option(accordion, tooltip, modal etc) in app.js
	
Common js file for all pages which is included in app.js and bundled
	
Each pages have its own js file to reduce load

Added Pug for module based integration