import $ from 'jquery';
window.jQuery = $;  
window.$ = $;

import 'bootstrap/js/dist/popover';
import 'bootstrap/js/dist/tooltip';
import 'bootstrap/js/dist/dropdown';
import 'bootstrap/js/dist/collapse';
import 'bootstrap/js/dist/tab';
import 'bootstrap/js/dist/modal';


// import './assets/js/vendor/slick';

import './assets/js/custom';
// import './assets/js/script';