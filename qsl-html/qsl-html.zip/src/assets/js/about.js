$(function(){
    console.log("about page");
    $('[data-bs-toggle="tooltip"]').tooltip();
    //your code here
})