$(function(){
    console.log("common pages");
    // $('[data-bs-toggle="popover"]').popover();
})