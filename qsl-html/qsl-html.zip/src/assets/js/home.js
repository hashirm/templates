$(function(){
    console.log("home page");
    // $('[data-bs-toggle="popover"]').popover();
    //your code here
})