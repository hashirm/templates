<?php

    if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === "off") {
    $location = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $location);
    exit;
}
?><!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="./assets/tfbltd.png" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
        integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="css/style.css">
    <title>Tbl LTD</title>
    <style>
        /* @media(max-width:480px){
            .mobile-height{
                height:100% !important;
                width:auto !important;

            }
        } */
    </style>
</head>

<body>

    <div class="bg-light">
        <div class="container">
            <div class="d-flex align-items-center justify-content-between">
                <ul class="d-flex list-unstyled">
                    <!-- <li><i class="fa-solid fa-phone-flip"></i> 444444444</li>
                    &nbsp;
                    &nbsp; -->
                    <li><i class="fa-solid fa-envelope"></i> <a class="text-decoration-none text-dark ms-2"
                            href="mailto:support@tfbltd.com"> support@tfbltd.com</a></li>
                </ul>
                <ul class="d-flex list-unstyled">
                    <li class="mx-2"> <a href="#" class="text-dark"> <i class="fa-brands fa-square-facebook"></i></a>
                    </li>
                    <li class="mx-2"><a href="#" class="text-dark"> <i class="fa-brands fa-square-instagram"></i></a>
                    </li>
                    <li class="mx-2"><a href="#" class="text-dark"> <i class="fa-brands fa-square-twitter"></i></a>
                    </li>
                    <li class="mx-2"><a href="#" class="text-dark"> <i class="fa-brands fa-square-behance"></i></a>
                    </li>
                    <li class="mx-2"><a href="#" class="text-dark"> <i class="fa-brands fa-square-pinterest"></i></a>
                    </li>

                    <li class="ms-5 d-none menu-icon">
                        <span class="material-symbols-outlined">
                            menu
                        </span>
                    </li>

                </ul>
            </div>
        </div>
    </div>

    <nav class="">
        <div class="shadow">
            <div class="container">

                <div class="d-flex justify-content-center align-items-center py-2">
                    <div class="d-flex justify-content-center">
                        <img class="logo" style="width:70%;" src="./assets/tfbltd.png" alt="">

                    </div>
               
                    

                </div>
            </div>
        </div>
        <div class="mobile-menu-bg overflow-hidden d-flex flex-column position-relative">
            <div class="container">
                <!-- <ul class="d-flex flex-column list-unstyled justify-content-between position-absolute">
                    <li class="mx-3 my-2 border border-bottom-2 border-top-0 border-start-0 border-end-0"><strong><a
                                href="#" class="text-decoration-none text-dark">Home </a> </strong></li>
                    <li class="mx-3 my-2 border border-bottom-2 border-top-0 border-start-0 border-end-0"><strong><a
                                href="#technology" class="text-decoration-none text-dark">Our
                                Technology</a></strong></li>

                    <li class="mx-3 my-2 border border-bottom-2 border-top-0 border-start-0 border-end-0"><strong><a
                                href="#about" class="text-decoration-none text-dark">About Us</a></strong>
                    </li>
                    <li class="mx-3 my-2 border border-bottom-2 border-top-0 border-start-0 border-end-0"><strong><a
                                href="#termandcondition" class="text-decoration-none text-dark">Terms and
                                Conditions</a></strong></li>
                    <li class="mx-3 my-2 border border-bottom-2 border-top-0 border-start-0 border-end-0"><strong><a
                                href="#privacypolicy" class="text-decoration-none text-dark">Privacy
                                Policy</a></strong></li>
                    <li class="mx-3 my-2 border border-bottom-2 border-top-0 border-start-0 border-end-0"><strong><a
                                href="#blog" class="text-decoration-none text-dark">Blog</a></strong></li>
                    <li class="mx-3 my-2 border border-bottom-2 border-top-0 border-start-0 border-end-0"><strong><a
                                href="#contactus" class="text-decoration-none text-dark">Contact Us</a></strong>
                    </li>
                </ul> -->
            </div>
        </div>
    </nav>
    <div class="body">
        <div class="position-relative bg-video w-100">

            <!-- <iframe width="100%" height="600" class="w-100" src="./assets/banner-03.jpg">
            </iframe> -->
            <img class="mobile-height w-100" src="./assets/banner-03.jpg" alt="">

            <div class="position-absolute text-main w-50">
                <h1 class="text-white">MT4, Offer more trading platforms to attract and recruite more traders</h1>
                <p class="text-white para-main mt-4">
                </p>
                <button class="border border-1 text-dark mt-2 fs-4 px-3 py-1 rounded">Learn More</button>
            </div>

        </div>

        <div class="tfbltd">
            <div class="container pt-5 pb-5">
                <div class="row mt-5 justify-content-between align-items-center">

                    <div class="col-lg-5 col-sm-12">
                        <h1><span style="text-decoration: underline;color:blueviolet">TFB LTD</span> WORLD CLASS
                            PLATFORMS</h1>

                        <p class=""><span>MT4</p>
                        <ul class="list-unstyled">
                            <li class="my-2"><i class="fa-solid fa-check"></i> Fast, reliable trade execution</li>
                            <li class="my-2"><i class="fa-solid fa-check"></i> Multi-asset coverage; FX, Indices
                                Commodities
                            </li>
                            <li class="my-2"><i class="fa-solid fa-check"></i> No dealing desk, no requotes</li>
                            <li class="my-2"><i class="fa-solid fa-check"></i> Technical tools & indicators</li>
                        </ul>
                        <button class="bg-transparent border border-1 mt-4 p-2">FIND OUT MORE</button>
                    </div>

                    <div class="col-lg-5 col-sm-12">
                        <img class="w-100" src="./assets/mobilepone.png" alt="" srcset="">
                    </div>

                </div>
            </div>
        </div>

        <div class="section-03 bg-light py-5" id="about">
            <div class="container">
                <div class="row mt-5 justify-content-between">

                    <div class="col-lg-4 col-sm-12">
                        <h1>WHY <span>TFB LTD</span></h1>

                        <P>Fast, reliable trade execution
                            Multi-asset coverage; FX, Indices Commodities
                            No dealing desk, no requotes
                            Technical tools & indicators</P>
                    </div>
                    <div class="col-lg-7 col-sm-12 d-flex justify-content-between text-center sec-03-part-02">
                        <div class="box-one">
                            <i class="fa-solid fa-money-bill-transfer fa-4x" style="color:blueviolet;"></i>
                            <h5 class="my-4">FIN TECH Platform</h5>
                            <p>World most popular trading platform</p>
                        </div>
                        <div class="box-two">

                            <i class="fa-solid fa-arrow-down-up-lock fa-4x" style="color:white"></i>

                            <h5 class="my-4">CRM</h5>
                            <p>World most popular trading platform</p>
                        </div>
                        <div class="box-three">
                            <i class="fa-solid fa-arrow-right-to-city fa-4x" style="color:blueviolet;"></i>
                            <h5 class="my-4">consulting</h5>
                            <p>World most popular trading platform</p>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="section-04 p-5" id="technology">
            <div class="container pt-5 pb-5">

                <div class="row align-items-center justify-content-between gap-4">

                    <div class="col-lg-4 col-sm-12">
                        <img class="w-100" src="./assets/image-00.png" alt="">
                    </div>
                    <div class="col-lg-5 col-sm-12 text-white">
                        <h3 class="text-decoration-underline my-4">TFB LTD</h3>
                        <p> Technology (CRM + Trading Platforms) Liquidity (Multi Asset Liquidity from trusted Prime
                            traders) Payment and CRMs integrated with all the leading trading platforms including MT4
                            MetaQuotes.

                        </p>


                    </div>

                </div>
            </div>

        </div>
        <div class="section-05 p-5">
            <div class="container pt-5 pb-5">
                <div class="row align-items-center justify-content-between gap-4">
                    <div class="col-lg-5 col-sm-12 text-dark">
                        <h3 class="">
                            MORE ABOUT <br>
                            <span class="text-decoration-underline">TFB LTD</span>
                        </h3>
                        <p>Therefore, you ought certain you are able do it a few hours and to purchase on article
                            anytime
                            you need. As a consequence it seeming to earn an income from writing enroling with an essay
                            writing.</p>
                        <button class="btn btn-danger">Find Out More</button>

                    </div>
                    <div class="col-lg-5 col-sm-12">
                        <img class="w-100" src="./assets/list-d14.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-light py-5 section-06" id="blog">
            <div class="container py-2">
                <div class="text-center">
                    <h1 class="mb-5 text-dark" style="font-weight:bold">
                        WHAT TO EXPECT WITH <span
                            style="font-size: 2.5rem; font-weight:bold;color:blueviolet;text-decoration: underline;">TFB
                            LTD</span>
                    </h1>
                </div>
                <div class="flex-container d-flex justify-content-between align-items-center">
                    <div class="flex-item d-flex flex-column align-items-center">
                        <img class="w-75" src="./assets/image-01.png" alt="" srcset="">
                        <p class="text-center"><strong>TELL US WHAT YOU ARE LOOKING FOR</strong></p>
                    </div>
                    <div class="flex-item d-flex flex-column align-items-center">
                        <img class="w-75" src="./assets/image-02.png" alt="" srcset="">
                        <p class="text-center"><strong>AN EXPERIENCE REPRESENTATIVE WILL CONTACT YOU</strong></p>
                    </div>
                    <div class="flex-item d-flex flex-column align-items-center">
                        <img class="w-75" src="./assets/image-03.png" alt="" srcset="">
                        <p class="text-center"><strong>RECIEVE A PROPOSAL</strong></p>
                    </div>
                    <div class="flex-item d-flex flex-column align-items-center">
                        <img class="w-75" src="./assets/image-04.png" alt="" srcset="">
                        <p class="text-center"><strong>AGREEMENT- WE WILL BEGIN TO BE OF SERVICE</strong></p>
                    </div>

                </div>
            </div>
        </div>
        <div>
            <div class="d-flex contact-section" style="background-color:blueviolet" id="contactus">
                <div class="d-flex flex-column align-items-center w-75 mx-5 py-5 contact-form">

                    <h1 class="text-white w-75 text-left">REQUEST A FREE CONSULTATION</h1>
                    <P class="text-white w-75 text-left">What makes our consultation different? Our focus is to see you
                        succeed and by the very first
                        discussion you will see this</P>
                    <form action="" class="d-flex flex-column w-75">

                        <div class="d-flex justify-content-between my-3">
                            <input type="text" class="form-control" placeholder="Your Name"> &nbsp;&nbsp;&nbsp; <input
                                type="text" class="form-control" placeholder="Your Email">
                        </div>

                        <div class="d-flex">
                            <input type="number" class="form-control" placeholder="phone"> &nbsp;&nbsp;&nbsp;<input
                                type="text" class="form-control" placeholder="Platform">
                        </div>

                        <textarea class="form-control my-3" name="" id="" cols="30" rows="10"
                            placeholder="Other Details"></textarea>

                        <input type="submit" value="Find your Advisor" class="btn btn-light w-25 button-submit">

                    </form>
                </div>

                <div>
                    <img class="w-100 h-100" src="./assets/contact-section=img.JPG" alt="" srcset="">
                </div>
            </div>
        </div>
        <div class="bg-dark d-flex flex-column align-center justify-content-center py-3 footer" id="privacypolicy">

            <div>
                <p style="color:#dbc4c4;line-height:30px" class="mt-4 text-center">&copy; 2022. All rights reserved. TFB Ltd - Registration #
                    22580. <br> Registered
                    office is Beachmont Business Centre Ste 7, Beachmont, Kingstown, Saint
                    Vincent & Grenadines</p>
            </div>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
        </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"
        integrity="sha512-aVKKRRi/Q/YV+4mjoKBsE4x3H+BkegoM/em46NNlCqNTmUYADjBbeNefNxYV7giUp0VxICtqdrbqU7iVaeZNXA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="JS/app.js"></script>
</body>

</html>